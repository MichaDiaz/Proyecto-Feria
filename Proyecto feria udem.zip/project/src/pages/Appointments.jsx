import React, { useState } from 'react'
import { Calendar, Clock, User, Phone, Mail, FileText } from 'lucide-react'
import { useAuth } from '../context/AuthContext'
import { useNotification } from '../context/NotificationContext'

const Appointments = () => {
  const { user } = useAuth()
  const { showNotification } = useNotification()
  
  const [formData, setFormData] = useState({
    patientName: user?.name || '',
    patientPhone: '',
    patientEmail: user?.email || '',
    appointmentDate: '',
    appointmentTime: '',
    prosthesisType: '',
    medicalHistory: ''
  })

  const handleSubmit = (e) => {
    e.preventDefault()
    
    if (!user) {
      showNotification('Debes iniciar sesión para agendar una cita', 'error')
      return
    }

    // Simulate appointment booking
    const appointmentId = `APT-${Date.now().toString().slice(-6)}`
    showNotification(`Cita ${appointmentId} agendada exitosamente`, 'success')
    
    // Reset form
    setFormData({
      ...formData,
      appointmentDate: '',
      appointmentTime: '',
      prosthesisType: '',
      medicalHistory: ''
    })
  }

  const handleChange = (e) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }))
  }

  const processSteps = [
    {
      number: 1,
      title: "Consulta Inicial",
      description: "Evaluación médica completa y análisis de necesidades específicas del paciente."
    },
    {
      number: 2,
      title: "Diseño Personalizado",
      description: "Creación de diseño 3D personalizado basado en medidas y requerimientos únicos."
    },
    {
      number: 3,
      title: "Fabricación",
      description: "Manufactura con tecnología avanzada y materiales de alta calidad."
    },
    {
      number: 4,
      title: "Entrega y Seguimiento",
      description: "Entrega del producto final con capacitación y seguimiento continuo."
    }
  ]

  return (
    <div className="appointments-page">
      <div className="container">
        <section className="appointments-section">
          <h1 className="section-title">Agendar Consulta Médica</h1>
          
          <div className="appointments-content">
            <div className="appointment-info">
              <h3>Proceso de Consulta</h3>
              <div className="process-steps">
                {processSteps.map(step => (
                  <div key={step.number} className="step">
                    <div className="step-number">{step.number}</div>
                    <div className="step-content">
                      <h4>{step.title}</h4>
                      <p>{step.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="appointment-form">
              <form onSubmit={handleSubmit} className="form">
                <div className="form-row">
                  <div className="form-group">
                    <label htmlFor="patientName">
                      <User size={16} />
                      Nombre Completo
                    </label>
                    <input
                      type="text"
                      id="patientName"
                      name="patientName"
                      value={formData.patientName}
                      onChange={handleChange}
                      placeholder="Nombre del paciente"
                      required
                    />
                  </div>
                  
                  <div className="form-group">
                    <label htmlFor="patientPhone">
                      <Phone size={16} />
                      Teléfono
                    </label>
                    <input
                      type="tel"
                      id="patientPhone"
                      name="patientPhone"
                      value={formData.patientPhone}
                      onChange={handleChange}
                      placeholder="Número de contacto"
                      required
                    />
                  </div>
                </div>

                <div className="form-group">
                  <label htmlFor="patientEmail">
                    <Mail size={16} />
                    Correo Electrónico
                  </label>
                  <input
                    type="email"
                    id="patientEmail"
                    name="patientEmail"
                    value={formData.patientEmail}
                    onChange={handleChange}
                    placeholder="correo@ejemplo.com"
                    required
                  />
                </div>

                <div className="form-row">
                  <div className="form-group">
                    <label htmlFor="appointmentDate">
                      <Calendar size={16} />
                      Fecha de Cita
                    </label>
                    <input
                      type="date"
                      id="appointmentDate"
                      name="appointmentDate"
                      value={formData.appointmentDate}
                      onChange={handleChange}
                      min={new Date().toISOString().split('T')[0]}
                      required
                    />
                  </div>
                  
                  <div className="form-group">
                    <label htmlFor="appointmentTime">
                      <Clock size={16} />
                      Hora de Cita
                    </label>
                    <select
                      id="appointmentTime"
                      name="appointmentTime"
                      value={formData.appointmentTime}
                      onChange={handleChange}
                      required
                    >
                      <option value="">Seleccionar hora</option>
                      <option value="09:00">09:00 AM</option>
                      <option value="10:00">10:00 AM</option>
                      <option value="11:00">11:00 AM</option>
                      <option value="14:00">02:00 PM</option>
                      <option value="15:00">03:00 PM</option>
                      <option value="16:00">04:00 PM</option>
                    </select>
                  </div>
                </div>

                <div className="form-group">
                  <label htmlFor="prosthesisType">
                    Tipo de Prótesis de Interés
                  </label>
                  <select
                    id="prosthesisType"
                    name="prosthesisType"
                    value={formData.prosthesisType}
                    onChange={handleChange}
                    required
                  >
                    <option value="">Seleccionar tipo</option>
                    <option value="brazo">Prótesis de Brazo</option>
                    <option value="mano">Prótesis de Mano</option>
                    <option value="pierna">Prótesis de Pierna</option>
                    <option value="pie">Prótesis de Pie</option>
                    <option value="dedos">Prótesis de Dedos</option>
                    <option value="facial">Prótesis Facial</option>
                  </select>
                </div>

                <div className="form-group">
                  <label htmlFor="medicalHistory">
                    <FileText size={16} />
                    Historia Médica (Opcional)
                  </label>
                  <textarea
                    id="medicalHistory"
                    name="medicalHistory"
                    value={formData.medicalHistory}
                    onChange={handleChange}
                    placeholder="Información médica relevante, cirugías previas, alergias, etc."
                    rows="4"
                  />
                </div>

                <button type="submit" className="btn-primary full-width">
                  <Calendar size={20} />
                  Agendar Consulta
                </button>
              </form>
            </div>
          </div>
        </section>
      </div>
    </div>
  )
}

export default Appointments