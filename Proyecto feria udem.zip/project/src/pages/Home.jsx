import React from 'react'
import { Link } from 'react-router-dom'
import { ArrowRight, Users, Award, Clock, Shield } from 'lucide-react'

const Home = () => {
  const featuredProducts = [
    {
      id: 4,
      name: "Mano Biónica Inteligente",
      category: "mano",
      price: 35000,
      originalPrice: 40000,
      image: "https://images.pexels.com/photos/8376281/pexels-photo-8376281.jpeg?auto=compress&cs=tinysrgb&w=400",
      description: "Mano protésica con IA integrada, 15 patrones de agarre y control intuitivo."
    },
    {
      id: 6,
      name: "Prótesis de Pierna con Rodilla Inteligente",
      category: "pierna",
      price: 45000,
      originalPrice: 50000,
      image: "https://images.pexels.com/photos/8376283/pexels-photo-8376283.jpeg?auto=compress&cs=tinysrgb&w=400",
      description: "Prótesis de pierna con rodilla microcontrolada y adaptación automática al terreno."
    },
    {
      id: 15,
      name: "Sistema Protésico Completo Brazo",
      category: "brazo",
      price: 65000,
      originalPrice: 75000,
      image: "https://images.pexels.com/photos/8376292/pexels-photo-8376292.jpeg?auto=compress&cs=tinysrgb&w=400",
      description: "Sistema completo de brazo con hombro, codo y mano integrados con IA."
    }
  ]

  return (
    <div className="home-page">
      {/* Hero Section */}
      <section className="hero">
        <div className="hero-background">
          <div className="hero-particles"></div>
        </div>
        
        <div className="container">
          <div className="hero-content">
            <h1 className="hero-title">
              Prótesis Biomédicas del Futuro
            </h1>
            <p className="hero-subtitle">
              Tecnología avanzada que restaura la movilidad y mejora la calidad de vida. 
              Diseños personalizados con materiales de última generación y control inteligente.
            </p>
            
            <div className="hero-stats">
              <div className="stat">
                <span className="stat-number">500+</span>
                <span className="stat-label">Pacientes Atendidos</span>
              </div>
              <div className="stat">
                <span className="stat-number">15</span>
                <span className="stat-label">Años de Experiencia</span>
              </div>
              <div className="stat">
                <span className="stat-number">98%</span>
                <span className="stat-label">Satisfacción</span>
              </div>
            </div>
            
            <div className="hero-buttons">
              <Link to="/products" className="cta-btn primary">
                Ver Productos
                <ArrowRight size={20} />
              </Link>
              <Link to="/appointments" className="cta-btn secondary">
                Agendar Consulta
              </Link>
            </div>
          </div>
          
          <div className="hero-image">
            <img 
              src="https://images.pexels.com/photos/8376277/pexels-photo-8376277.jpeg?auto=compress&cs=tinysrgb&w=600" 
              alt="Prótesis biomédica avanzada"
            />
            <div className="hero-overlay"></div>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="featured-section">
        <div className="container">
          <h2 className="section-title">Productos Destacados</h2>
          <div className="featured-grid">
            {featuredProducts.map(product => {
              const discount = Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
              
              return (
                <div key={product.id} className="featured-card">
                  <div className="featured-badge">-{discount}%</div>
                  <img src={product.image} alt={product.name} className="featured-image" />
                  <h3 className="featured-title">{product.name}</h3>
                  <p className="featured-description">{product.description}</p>
                  <div className="featured-price">${product.price.toLocaleString()}</div>
                  <Link to="/products" className="add-to-cart">
                    Ver Detalles
                  </Link>
                </div>
              )
            })}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="features-section">
        <div className="container">
          <h2 className="section-title">¿Por Qué Elegirnos?</h2>
          <div className="features-grid">
            <div className="feature-card">
              <div className="feature-icon">
                <Award size={32} />
              </div>
              <h3>Tecnología Avanzada</h3>
              <p>Utilizamos los materiales más innovadores y tecnología de punta para crear prótesis de alta calidad.</p>
            </div>
            
            <div className="feature-card">
              <div className="feature-icon">
                <Users size={32} />
              </div>
              <h3>Equipo Especializado</h3>
              <p>Nuestro equipo de profesionales cuenta con años de experiencia en biomedicina y rehabilitación.</p>
            </div>
            
            <div className="feature-card">
              <div className="feature-icon">
                <Clock size={32} />
              </div>
              <h3>Atención 24/7</h3>
              <p>Brindamos soporte continuo y seguimiento personalizado para garantizar tu bienestar.</p>
            </div>
            
            <div className="feature-card">
              <div className="feature-icon">
                <Shield size={32} />
              </div>
              <h3>Garantía Extendida</h3>
              <p>Todos nuestros productos incluyen garantía extendida y mantenimiento especializado.</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default Home