import React, { useState } from 'react'
import { User, Mail, Phone, MapPin, Calendar, Package, Clock } from 'lucide-react'
import { useAuth } from '../context/AuthContext'

const Profile = () => {
  const { user } = useAuth()
  const [activeTab, setActiveTab] = useState('profile')
  
  const [profileData, setProfileData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    phone: '',
    address: '',
    birthDate: '',
    medicalInfo: ''
  })

  const handleChange = (e) => {
    setProfileData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }))
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    // Save profile data logic here
    console.log('Profile updated:', profileData)
  }

  // Mock data for appointments and orders
  const appointments = [
    {
      id: 1,
      date: '2024-01-15',
      time: '10:00',
      type: 'Consulta inicial',
      status: 'completed'
    },
    {
      id: 2,
      date: '2024-01-22',
      time: '14:00',
      type: 'Seguimiento',
      status: 'scheduled'
    }
  ]

  const orders = [
    {
      id: 'BTP-001234',
      date: '2024-01-10',
      items: ['Prótesis de Mano Biónica'],
      total: 35000,
      status: 'processing'
    }
  ]

  if (!user) {
    return (
      <div className="profile-page">
        <div className="container">
          <div className="empty-cart">
            <User size={64} />
            <h3>Acceso Restringido</h3>
            <p>Debes iniciar sesión para ver tu perfil</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="profile-page">
      <div className="container">
        <h1 className="section-title">Mi Perfil</h1>
        
        <div className="profile-tabs">
          <button 
            className={`tab-btn ${activeTab === 'profile' ? 'active' : ''}`}
            onClick={() => setActiveTab('profile')}
          >
            <User size={20} />
            Información Personal
          </button>
          <button 
            className={`tab-btn ${activeTab === 'appointments' ? 'active' : ''}`}
            onClick={() => setActiveTab('appointments')}
          >
            <Calendar size={20} />
            Mis Citas
          </button>
          <button 
            className={`tab-btn ${activeTab === 'orders' ? 'active' : ''}`}
            onClick={() => setActiveTab('orders')}
          >
            <Package size={20} />
            Mis Pedidos
          </button>
        </div>

        <div className="profile-content">
          {activeTab === 'profile' && (
            <div className="profile-section">
              <div className="profile-header">
                <div className="profile-avatar">
                  <img src={user.picture} alt={user.name} />
                </div>
                <div className="profile-info">
                  <h2>{user.name}</h2>
                  <p>{user.email}</p>
                  <span className="member-since">
                    Miembro desde {new Date(user.loginTime).getFullYear()}
                  </span>
                </div>
              </div>

              <form onSubmit={handleSubmit} className="profile-form">
                <div className="form-row">
                  <div className="form-group">
                    <label htmlFor="name">
                      <User size={16} />
                      Nombre Completo
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={profileData.name}
                      onChange={handleChange}
                      placeholder="Tu nombre completo"
                    />
                  </div>
                  
                  <div className="form-group">
                    <label htmlFor="email">
                      <Mail size={16} />
                      Correo Electrónico
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={profileData.email}
                      onChange={handleChange}
                      placeholder="tu@email.com"
                    />
                  </div>
                </div>

                <div className="form-row">
                  <div className="form-group">
                    <label htmlFor="phone">
                      <Phone size={16} />
                      Teléfono
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      value={profileData.phone}
                      onChange={handleChange}
                      placeholder="Tu número de teléfono"
                    />
                  </div>
                  
                  <div className="form-group">
                    <label htmlFor="birthDate">
                      <Calendar size={16} />
                      Fecha de Nacimiento
                    </label>
                    <input
                      type="date"
                      id="birthDate"
                      name="birthDate"
                      value={profileData.birthDate}
                      onChange={handleChange}
                    />
                  </div>
                </div>

                <div className="form-group">
                  <label htmlFor="address">
                    <MapPin size={16} />
                    Dirección
                  </label>
                  <input
                    type="text"
                    id="address"
                    name="address"
                    value={profileData.address}
                    onChange={handleChange}
                    placeholder="Tu dirección completa"
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="medicalInfo">
                    Información Médica
                  </label>
                  <textarea
                    id="medicalInfo"
                    name="medicalInfo"
                    value={profileData.medicalInfo}
                    onChange={handleChange}
                    placeholder="Información médica relevante, alergias, etc."
                    rows="4"
                  />
                </div>

                <button type="submit" className="btn-primary">
                  Guardar Cambios
                </button>
              </form>
            </div>
          )}

          {activeTab === 'appointments' && (
            <div className="appointments-list">
              <h3>Historial de Citas</h3>
              {appointments.length === 0 ? (
                <div className="empty-cart">
                  <Calendar size={64} />
                  <h3>No tienes citas agendadas</h3>
                  <p>Agenda tu primera consulta médica</p>
                </div>
              ) : (
                appointments.map(appointment => (
                  <div key={appointment.id} className="appointment-card">
                    <div className="appointment-header">
                      <div className="appointment-date">
                        <Calendar size={20} />
                        {new Date(appointment.date).toLocaleDateString()}
                      </div>
                      <div className="appointment-time">
                        <Clock size={16} />
                        {appointment.time}
                      </div>
                      <div className={`appointment-status ${appointment.status}`}>
                        {appointment.status === 'completed' ? 'Completada' : 'Programada'}
                      </div>
                    </div>
                    <div className="appointment-details">
                      <p><strong>Tipo:</strong> {appointment.type}</p>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {activeTab === 'orders' && (
            <div className="orders-list">
              <h3>Historial de Pedidos</h3>
              {orders.length === 0 ? (
                <div className="empty-cart">
                  <Package size={64} />
                  <h3>No tienes pedidos</h3>
                  <p>Realiza tu primer pedido</p>
                </div>
              ) : (
                orders.map(order => (
                  <div key={order.id} className="order-card">
                    <div className="order-header">
                      <div className="order-number">Pedido {order.id}</div>
                      <div className="order-date">
                        {new Date(order.date).toLocaleDateString()}
                      </div>
                      <div className={`order-status ${order.status}`}>
                        {order.status === 'processing' ? 'En Proceso' : order.status}
                      </div>
                    </div>
                    <div className="order-items">
                      {order.items.map((item, index) => (
                        <div key={index} className="order-item">
                          <span>{item}</span>
                        </div>
                      ))}
                    </div>
                    <div className="order-total">
                      Total: ${order.total.toLocaleString()}
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default Profile