import React, { useState, useEffect } from 'react'
import { Search, Filter, Grid, List, X } from 'lucide-react'
import ProductCard from '../components/ProductCard'
import Product3DViewer from '../components/Product3DViewer'
import { products } from '../data/products'

const Products = () => {
  const [filteredProducts, setFilteredProducts] = useState(products)
  const [currentPage, setCurrentPage] = useState(1)
  const [itemsPerPage] = useState(12)
  const [viewMode, setViewMode] = useState('grid')
  const [selectedProduct, setSelectedProduct] = useState(null)
  const [isModalOpen, setIsModalOpen] = useState(false)
  
  const [filters, setFilters] = useState({
    search: '',
    category: '',
    type: '',
    priceRange: ''
  })

  useEffect(() => {
    let filtered = [...products]

    // Search filter
    if (filters.search) {
      filtered = filtered.filter(product =>
        product.name.toLowerCase().includes(filters.search.toLowerCase()) ||
        product.description.toLowerCase().includes(filters.search.toLowerCase())
      )
    }

    // Category filter
    if (filters.category) {
      filtered = filtered.filter(product => product.category === filters.category)
    }

    // Type filter
    if (filters.type) {
      filtered = filtered.filter(product => product.type === filters.type)
    }

    // Price range filter
    if (filters.priceRange) {
      const [min, max] = filters.priceRange.split('-').map(p => p.replace('+', ''))
      const minPrice = parseInt(min)
      const maxPrice = max ? parseInt(max) : Infinity
      
      filtered = filtered.filter(product => 
        product.price >= minPrice && product.price <= maxPrice
      )
    }

    setFilteredProducts(filtered)
    setCurrentPage(1)
  }, [filters])

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }))
  }

  const clearFilters = () => {
    setFilters({
      search: '',
      category: '',
      type: '',
      priceRange: ''
    })
  }

  const handleViewDetails = (product) => {
    setSelectedProduct(product)
    setIsModalOpen(true)
  }

  // Pagination
  const totalPages = Math.ceil(filteredProducts.length / itemsPerPage)
  const startIndex = (currentPage - 1) * itemsPerPage
  const endIndex = startIndex + itemsPerPage
  const currentProducts = filteredProducts.slice(startIndex, endIndex)

  const categories = [...new Set(products.map(p => p.category))]
  const types = [...new Set(products.map(p => p.type))]

  return (
    <div className="products-page">
      <div className="container">
        <div className="products-header">
          <h1 className="section-title">Catálogo de Prótesis</h1>
          
          {/* Search and Filters */}
          <div className="products-controls">
            <div className="search-section">
              <div className="search-bar">
                <Search size={20} />
                <input
                  type="text"
                  placeholder="Buscar prótesis..."
                  value={filters.search}
                  onChange={(e) => handleFilterChange('search', e.target.value)}
                />
              </div>
            </div>

            <div className="filter-controls">
              <select
                value={filters.category}
                onChange={(e) => handleFilterChange('category', e.target.value)}
                className="filter-select"
              >
                <option value="">Todas las categorías</option>
                {categories.map(category => (
                  <option key={category} value={category}>
                    {category.charAt(0).toUpperCase() + category.slice(1)}
                  </option>
                ))}
              </select>

              <select
                value={filters.type}
                onChange={(e) => handleFilterChange('type', e.target.value)}
                className="filter-select"
              >
                <option value="">Todos los tipos</option>
                {types.map(type => (
                  <option key={type} value={type}>
                    {type.charAt(0).toUpperCase() + type.slice(1)}
                  </option>
                ))}
              </select>

              <select
                value={filters.priceRange}
                onChange={(e) => handleFilterChange('priceRange', e.target.value)}
                className="filter-select"
              >
                <option value="">Todos los precios</option>
                <option value="0-10000">$0 - $10,000</option>
                <option value="10000-25000">$10,000 - $25,000</option>
                <option value="25000-50000">$25,000 - $50,000</option>
                <option value="50000+">$50,000+</option>
              </select>

              <button className="filter-btn" onClick={clearFilters}>
                <X size={16} />
                Limpiar
              </button>
            </div>

            <div className="view-controls">
              <button
                className={`view-btn ${viewMode === 'grid' ? 'active' : ''}`}
                onClick={() => setViewMode('grid')}
              >
                <Grid size={20} />
              </button>
              <button
                className={`view-btn ${viewMode === 'list' ? 'active' : ''}`}
                onClick={() => setViewMode('list')}
              >
                <List size={20} />
              </button>
            </div>
          </div>
        </div>

        {/* Products Grid */}
        <div className={`products-grid ${viewMode === 'list' ? 'list-view' : ''}`}>
          {currentProducts.map(product => (
            <ProductCard
              key={product.id}
              product={product}
              onViewDetails={handleViewDetails}
            />
          ))}
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="pagination">
            {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
              <button
                key={page}
                className={`pagination-btn ${page === currentPage ? 'active' : ''}`}
                onClick={() => setCurrentPage(page)}
              >
                {page}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* 3D Product Modal */}
      {isModalOpen && selectedProduct && (
        <div className="modal show">
          <div className="modal-content large">
            <div className="modal-header">
              <h2>{selectedProduct.name}</h2>
              <button className="close-btn" onClick={() => setIsModalOpen(false)}>
                <X size={24} />
              </button>
            </div>
            <div className="modal-body">
              <div className="product-detail">
                <div className="product-3d">
                  <Product3DViewer product={selectedProduct} />
                </div>
                <div className="product-info-detail">
                  <h3>{selectedProduct.name}</h3>
                  <p className="product-category">
                    {selectedProduct.category} - {selectedProduct.type}
                  </p>
                  <p>{selectedProduct.description}</p>
                  
                  <h4>Características:</h4>
                  <ul>
                    {selectedProduct.features.map((feature, index) => (
                      <li key={index}>{feature}</li>
                    ))}
                  </ul>
                  
                  <h4>Especificaciones:</h4>
                  <ul>
                    {Object.entries(selectedProduct.specifications).map(([key, value]) => (
                      <li key={key}><strong>{key}:</strong> {value}</li>
                    ))}
                  </ul>
                  
                  <div className="product-price" style={{ marginTop: '1rem' }}>
                    ${selectedProduct.price.toLocaleString()}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default Products