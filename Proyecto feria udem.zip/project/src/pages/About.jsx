import React from 'react'
import { Award, Users, Heart, Zap, Shield, Clock } from 'lucide-react'

const About = () => {
  const features = [
    {
      icon: <Award size={32} />,
      title: "Tecnología Avanzada",
      description: "Utilizamos los últimos avances en biomedicina y robótica para crear prótesis de vanguardia."
    },
    {
      icon: <Users size={32} />,
      title: "Equipo Especializado",
      description: "Profesionales con más de 15 años de experiencia en el diseño y fabricación de prótesis."
    },
    {
      icon: <Heart size={32} />,
      title: "Atención Personalizada",
      description: "Cada prótesis es única, diseñada específicamente para las necesidades de cada paciente."
    },
    {
      icon: <Zap size={32} />,
      title: "Innovación Continua",
      description: "Investigación constante para mejorar la funcionalidad y comodidad de nuestros productos."
    },
    {
      icon: <Shield size={32} />,
      title: "Calidad Garantizada",
      description: "Todos nuestros productos cumplen con los más altos estándares de calidad internacional."
    },
    {
      icon: <Clock size={32} />,
      title: "Soporte 24/7",
      description: "Asistencia técnica y seguimiento continuo para garantizar el mejor rendimiento."
    }
  ]

  return (
    <div className="about-page">
      <div className="container">
        {/* Hero Section */}
        <section className="about-hero">
          <div className="about-content">
            <div className="about-text">
              <h1 className="section-title">Sobre BioTech Pro</h1>
              <h2>Transformando Vidas a Través de la Tecnología</h2>
              <p>
                En BioTech Pro, nos dedicamos a crear prótesis biomédicas de última generación 
                que no solo restauran la funcionalidad, sino que mejoran significativamente 
                la calidad de vida de nuestros pacientes.
              </p>
              <p>
                Con más de 15 años de experiencia en el campo de la biomedicina, hemos ayudado 
                a más de 500 pacientes a recuperar su movilidad e independencia a través de 
                soluciones protésicas innovadoras y personalizadas.
              </p>
            </div>
            
            <div className="about-image">
              <img 
                src="https://images.pexels.com/photos/8376290/pexels-photo-8376290.jpeg?auto=compress&cs=tinysrgb&w=600" 
                alt="Equipo médico especializado"
              />
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="features-section">
          <h2 className="section-title">¿Por Qué Elegirnos?</h2>
          <div className="features-grid">
            {features.map((feature, index) => (
              <div key={index} className="feature">
                <div className="feature-icon">{feature.icon}</div>
                <div className="feature-content">
                  <h3>{feature.title}</h3>
                  <p>{feature.description}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Stats Section */}
        <section className="stats-section">
          <h2 className="section-title">Nuestros Logros</h2>
          <div className="stats-grid">
            <div className="stat-card">
              <div className="stat-number">500+</div>
              <div className="stat-label">Pacientes Atendidos</div>
            </div>
            <div className="stat-card">
              <div className="stat-number">15</div>
              <div className="stat-label">Años de Experiencia</div>
            </div>
            <div className="stat-card">
              <div className="stat-number">98%</div>
              <div className="stat-label">Satisfacción del Cliente</div>
            </div>
            <div className="stat-card">
              <div className="stat-number">20+</div>
              <div className="stat-label">Tipos de Prótesis</div>
            </div>
          </div>
        </section>

        {/* Mission Section */}
        <section className="mission-section">
          <div className="mission-content">
            <h2 className="section-title">Nuestra Misión</h2>
            <div className="mission-text">
              <p>
                Nuestra misión es proporcionar soluciones protésicas innovadoras y de alta calidad 
                que permitan a las personas recuperar su independencia y confianza. Creemos que 
                cada individuo merece acceso a la mejor tecnología biomédica disponible.
              </p>
              <p>
                Trabajamos incansablemente para desarrollar productos que no solo cumplan con las 
                necesidades funcionales, sino que también brinden comodidad, durabilidad y una 
                experiencia de usuario excepcional.
              </p>
            </div>
          </div>
        </section>

        {/* Team Section */}
        <section className="team-section">
          <h2 className="section-title">Nuestro Equipo</h2>
          <div className="team-grid">
            <div className="team-member">
              <img 
                src="https://images.pexels.com/photos/5327585/pexels-photo-5327585.jpeg?auto=compress&cs=tinysrgb&w=300" 
                alt="Dr. María González"
              />
              <h3>Dr. María González</h3>
              <p>Directora Médica</p>
              <span>Especialista en Medicina Física y Rehabilitación</span>
            </div>
            
            <div className="team-member">
              <img 
                src="https://images.pexels.com/photos/5327656/pexels-photo-5327656.jpeg?auto=compress&cs=tinysrgb&w=300" 
                alt="Ing. Carlos Rodríguez"
              />
              <h3>Ing. Carlos Rodríguez</h3>
              <p>Director de Ingeniería</p>
              <span>Ingeniero Biomédico con 12 años de experiencia</span>
            </div>
            
            <div className="team-member">
              <img 
                src="https://images.pexels.com/photos/5327921/pexels-photo-5327921.jpeg?auto=compress&cs=tinysrgb&w=300" 
                alt="Dra. Ana Martínez"
              />
              <h3>Dra. Ana Martínez</h3>
              <p>Especialista en Prótesis</p>
              <span>Experta en diseño y adaptación de prótesis</span>
            </div>
          </div>
        </section>
      </div>
    </div>
  )
}

export default About