import React, { createContext, useContext, useState, useEffect } from 'react'

const AuthContext = createContext()

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    // Check for existing user in localStorage
    const savedUser = localStorage.getItem('biotechUser')
    if (savedUser) {
      try {
        setUser(JSON.parse(savedUser))
      } catch (error) {
        console.error('Error parsing saved user:', error)
        localStorage.removeItem('biotechUser')
      }
    }
  }, [])

  const login = (email, password) => {
    setLoading(true)
    // Simulate API call
    setTimeout(() => {
      const userData = {
        id: Date.now(),
        name: email.split('@')[0],
        email: email,
        picture: `https://ui-avatars.com/api/?name=${email.split('@')[0]}&background=00d4ff&color=000`,
        loginTime: new Date().toISOString()
      }
      setUser(userData)
      localStorage.setItem('biotechUser', JSON.stringify(userData))
      setLoading(false)
    }, 1000)
  }

  const register = (name, email, password) => {
    setLoading(true)
    // Simulate API call
    setTimeout(() => {
      const userData = {
        id: Date.now(),
        name: name,
        email: email,
        picture: `https://ui-avatars.com/api/?name=${name}&background=00d4ff&color=000`,
        loginTime: new Date().toISOString()
      }
      setUser(userData)
      localStorage.setItem('biotechUser', JSON.stringify(userData))
      setLoading(false)
    }, 1000)
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem('biotechUser')
  }

  const value = {
    user,
    loading,
    login,
    register,
    logout
  }

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  )
}