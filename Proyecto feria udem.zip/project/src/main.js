// Biometric Prosthetics Platform - Main JavaScript

// Global state
let currentUser = null;
let cart = JSON.parse(localStorage.getItem('biotechCart')) || [];
let appointments = JSON.parse(localStorage.getItem('biotechAppointments')) || [];
let orders = JSON.parse(localStorage.getItem('biotechOrders')) || [];
let currentPage = 1;
let itemsPerPage = 12;
let filteredProducts = [];

// Prosthetic products database with real images
const products = [
    // Arm Prosthetics
    {
        id: 1,
        name: "Prótesis Mioeléctrica de Brazo Avanzada",
        category: "brazo",
        type: "mioeléctrica",
        price: 25000,
        originalPrice: 30000,
        image: "https://images.pexels.com/photos/8376277/pexels-photo-8376277.jpeg?auto=compress&cs=tinysrgb&w=400",
        description: "Prótesis de brazo con control mioeléctrico avanzado, múltiples grados de libertad y feedback táctil.",
        features: ["Control Mioeléctrico", "Feedback Táctil", "Resistente al Agua", "Batería 12h"],
        rating: 4.9,
        reviews: 127,
        specifications: {
            weight: "1.2 kg",
            batteryLife: "12 horas",
            material: "Titanio y Carbono",
            warranty: "3 años"
        }
    },
    {
        id: 2,
        name: "Prótesis Mecánica de Brazo Deportiva",
        category: "brazo",
        type: "deportiva",
        price: 15000,
        originalPrice: 18000,
        image: "https://images.pexels.com/photos/8376278/pexels-photo-8376278.jpeg?auto=compress&cs=tinysrgb&w=400",
        description: "Diseñada para actividades deportivas con materiales ultraligeros y resistentes.",
        features: ["Ultraligera", "Resistente Impactos", "Ajuste Rápido", "Ventilación"],
        rating: 4.7,
        reviews: 89,
        specifications: {
            weight: "0.8 kg",
            material: "Fibra de Carbono",
            resistance: "IP67",
            warranty: "2 años"
        }
    },
    {
        id: 3,
        name: "Prótesis Cosmética de Brazo Premium",
        category: "brazo",
        type: "cosmética",
        price: 8000,
        originalPrice: 10000,
        image: "https://images.pexels.com/photos/8376280/pexels-photo-8376280.jpeg?auto=compress&cs=tinysrgb&w=400",
        description: "Prótesis cosmética con apariencia ultra-realista y materiales biocompatibles.",
        features: ["Ultra-realista", "Biocompatible", "Personalizable", "Ligera"],
        rating: 4.6,
        reviews: 156,
        specifications: {
            weight: "0.6 kg",
            material: "Silicona Médica",
            customization: "100% Personalizable",
            warranty: "2 años"
        }
    },

    // Hand Prosthetics
    {
        id: 4,
        name: "Mano Biónica Inteligente",
        category: "mano",
        type: "mioeléctrica",
        price: 35000,
        originalPrice: 40000,
        image: "https://images.pexels.com/photos/8376281/pexels-photo-8376281.jpeg?auto=compress&cs=tinysrgb&w=400",
        description: "Mano protésica con IA integrada, 15 patrones de agarre y control intuitivo.",
        features: ["IA Integrada", "15 Patrones Agarre", "Control Intuitivo", "Sensores Presión"],
        rating: 4.9,
        reviews: 203,
        specifications: {
            weight: "0.5 kg",
            batteryLife: "16 horas",
            gripPatterns: "15 patrones",
            warranty: "5 años"
        }
    },
    {
        id: 5,
        name: "Prótesis de Mano Mecánica Profesional",
        category: "mano",
        type: "mecanica",
        price: 12000,
        originalPrice: 15000,
        image: "https://images.pexels.com/photos/8376282/pexels-photo-8376282.jpeg?auto=compress&cs=tinysrgb&w=400",
        description: "Mano mecánica de alta precisión para uso profesional y actividades detalladas.",
        features: ["Alta Precisión", "Control Cable", "Durabilidad", "Mantenimiento Fácil"],
        rating: 4.5,
        reviews: 134,
        specifications: {
            weight: "0.4 kg",
            material: "Aleación Titanio",
            precision: "±0.1mm",
            warranty: "3 años"
        }
    },

    // Leg Prosthetics
    {
        id: 6,
        name: "Prótesis de Pierna con Rodilla Inteligente",
        category: "pierna",
        type: "mioeléctrica",
        price: 45000,
        originalPrice: 50000,
        image: "https://images.pexels.com/photos/8376283/pexels-photo-8376283.jpeg?auto=compress&cs=tinysrgb&w=400",
        description: "Prótesis de pierna con rodilla microcontrolada y adaptación automática al terreno.",
        features: ["Rodilla Inteligente", "Adaptación Terreno", "Amortiguación", "Control App"],
        rating: 4.8,
        reviews: 167,
        specifications: {
            weight: "2.1 kg",
            batteryLife: "24 horas",
            maxWeight: "120 kg",
            warranty: "4 años"
        }
    },
    {
        id: 7,
        name: "Prótesis Deportiva de Pierna Running",
        category: "pierna",
        type: "deportiva",
        price: 28000,
        originalPrice: 32000,
        image: "https://images.pexels.com/photos/8376284/pexels-photo-8376284.jpeg?auto=compress&cs=tinysrgb&w=400",
        description: "Diseñada específicamente para corredores con retorno de energía optimizado.",
        features: ["Retorno Energía", "Ultraligera", "Aerodinámica", "Absorción Impacto"],
        rating: 4.7,
        reviews: 98,
        specifications: {
            weight: "1.3 kg",
            material: "Fibra Carbono",
            energyReturn: "85%",
            warranty: "3 años"
        }
    },
    {
        id: 8,
        name: "Prótesis Mecánica de Pierna Estándar",
        category: "pierna",
        type: "mecanica",
        price: 18000,
        originalPrice: 22000,
        image: "https://images.pexels.com/photos/8376285/pexels-photo-8376285.jpeg?auto=compress&cs=tinysrgb&w=400",
        description: "Prótesis mecánica confiable para uso diario con excelente durabilidad.",
        features: ["Uso Diario", "Durabilidad", "Ajuste Preciso", "Mantenimiento Mínimo"],
        rating: 4.4,
        reviews: 145,
        specifications: {
            weight: "1.8 kg",
            material: "Aleación Aluminio",
            maxWeight: "100 kg",
            warranty: "3 años"
        }
    },

    // Foot Prosthetics
    {
        id: 9,
        name: "Pie Protésico con Tobillo Dinámico",
        category: "pie",
        type: "mioeléctrica",
        price: 22000,
        originalPrice: 26000,
        image: "https://images.pexels.com/photos/8376286/pexels-photo-8376286.jpeg?auto=compress&cs=tinysrgb&w=400",
        description: "Pie protésico con tobillo motorizado para movimiento natural y adaptativo.",
        features: ["Tobillo Motorizado", "Movimiento Natural", "Sensores Terreno", "App Control"],
        rating: 4.6,
        reviews: 112,
        specifications: {
            weight: "0.9 kg",
            batteryLife: "20 horas",
            angleRange: "30°",
            warranty: "3 años"
        }
    },
    {
        id: 10,
        name: "Pie Deportivo de Alto Rendimiento",
        category: "pie",
        type: "deportiva",
        price: 16000,
        originalPrice: 19000,
        image: "https://images.pexels.com/photos/8376287/pexels-photo-8376287.jpeg?auto=compress&cs=tinysrgb&w=400",
        description: "Pie protésico optimizado para deportes con máximo retorno de energía.",
        features: ["Alto Rendimiento", "Retorno Energía", "Estabilidad", "Ligereza"],
        rating: 4.5,
        reviews: 87,
        specifications: {
            weight: "0.6 kg",
            material: "Carbono Avanzado",
            energyReturn: "90%",
            warranty: "2 años"
        }
    },

    // Finger Prosthetics
    {
        id: 11,
        name: "Prótesis de Dedos Articulada",
        category: "dedos",
        type: "mecanica",
        price: 5000,
        originalPrice: 6500,
        image: "https://images.pexels.com/photos/8376288/pexels-photo-8376288.jpeg?auto=compress&cs=tinysrgb&w=400",
        description: "Prótesis de dedos con articulaciones móviles y control individual.",
        features: ["Articulaciones Móviles", "Control Individual", "Silicona Médica", "Personalizable"],
        rating: 4.3,
        reviews: 76,
        specifications: {
            weight: "0.05 kg",
            material: "Silicona + Titanio",
            flexibility: "Natural",
            warranty: "2 años"
        }
    },
    {
        id: 12,
        name: "Dedos Biónicos con Sensores",
        category: "dedos",
        type: "mioeléctrica",
        price: 12000,
        originalPrice: 15000,
        image: "https://images.pexels.com/photos/8376289/pexels-photo-8376289.jpeg?auto=compress&cs=tinysrgb&w=400",
        description: "Dedos protésicos con sensores táctiles y control mioeléctrico preciso.",
        features: ["Sensores Táctiles", "Control Preciso", "Feedback Haptico", "Resistente Agua"],
        rating: 4.7,
        reviews: 94,
        specifications: {
            weight: "0.08 kg",
            batteryLife: "8 horas",
            sensitivity: "Alta",
            warranty: "3 años"
        }
    },

    // Facial Prosthetics
    {
        id: 13,
        name: "Prótesis Facial Personalizada",
        category: "facial",
        type: "cosmética",
        price: 18000,
        originalPrice: 22000,
        image: "https://images.pexels.com/photos/8376290/pexels-photo-8376290.jpeg?auto=compress&cs=tinysrgb&w=400",
        description: "Prótesis facial ultra-realista creada con escaneo 3D y materiales premium.",
        features: ["Ultra-realista", "Escaneo 3D", "Materiales Premium", "Ajuste Perfecto"],
        rating: 4.8,
        reviews: 65,
        specifications: {
            weight: "0.2 kg",
            material: "Silicona Médica",
            customization: "100%",
            warranty: "3 años"
        }
    },
    {
        id: 14,
        name: "Prótesis Ocular Avanzada",
        category: "facial",
        type: "cosmética",
        price: 8500,
        originalPrice: 11000,
        image: "https://images.pexels.com/photos/8376291/pexels-photo-8376291.jpeg?auto=compress&cs=tinysrgb&w=400",
        description: "Prótesis ocular con movimiento sincronizado y apariencia natural.",
        features: ["Movimiento Sincronizado", "Apariencia Natural", "Biocompatible", "Fácil Limpieza"],
        rating: 4.6,
        reviews: 89,
        specifications: {
            weight: "0.02 kg",
            material: "Acrílico Médico",
            movement: "Sincronizado",
            warranty: "2 años"
        }
    },

    // Advanced Prosthetics
    {
        id: 15,
        name: "Sistema Protésico Completo Brazo",
        category: "brazo",
        type: "mioeléctrica",
        price: 65000,
        originalPrice: 75000,
        image: "https://images.pexels.com/photos/8376292/pexels-photo-8376292.jpeg?auto=compress&cs=tinysrgb&w=400",
        description: "Sistema completo de brazo con hombro, codo y mano integrados con IA.",
        features: ["Sistema Completo", "IA Integrada", "Control Mental", "Feedback Neural"],
        rating: 5.0,
        reviews: 45,
        specifications: {
            weight: "2.5 kg",
            batteryLife: "18 horas",
            aiFeatures: "Avanzadas",
            warranty: "5 años"
        }
    },
    {
        id: 16,
        name: "Exoesqueleto de Piernas Motorizado",
        category: "pierna",
        type: "mioeléctrica",
        price: 85000,
        originalPrice: 95000,
        image: "https://images.pexels.com/photos/8376293/pexels-photo-8376293.jpeg?auto=compress&cs=tinysrgb&w=400",
        description: "Exoesqueleto motorizado para rehabilitación y movilidad asistida.",
        features: ["Motorizado", "Rehabilitación", "Sensores Múltiples", "Control Inteligente"],
        rating: 4.9,
        reviews: 32,
        specifications: {
            weight: "15 kg",
            batteryLife: "6 horas",
            maxSpeed: "5 km/h",
            warranty: "4 años"
        }
    },
    {
        id: 17,
        name: "Prótesis de Mano Impresa 3D",
        category: "mano",
        type: "mecanica",
        price: 3500,
        originalPrice: 5000,
        image: "https://images.pexels.com/photos/8376294/pexels-photo-8376294.jpeg?auto=compress&cs=tinysrgb&w=400",
        description: "Prótesis de mano fabricada con impresión 3D, personalizable y económica.",
        features: ["Impresión 3D", "Personalizable", "Económica", "Rápida Fabricación"],
        rating: 4.2,
        reviews: 156,
        specifications: {
            weight: "0.3 kg",
            material: "PLA Médico",
            printTime: "24 horas",
            warranty: "1 año"
        }
    },
    {
        id: 18,
        name: "Prótesis Infantil Adaptable",
        category: "brazo",
        type: "mecanica",
        price: 8500,
        originalPrice: 11000,
        image: "https://images.pexels.com/photos/8376295/pexels-photo-8376295.jpeg?auto=compress&cs=tinysrgb&w=400",
        description: "Prótesis diseñada para niños con crecimiento adaptable y colores personalizables.",
        features: ["Crecimiento Adaptable", "Colores Personalizables", "Segura", "Ligera"],
        rating: 4.8,
        reviews: 78,
        specifications: {
            weight: "0.4 kg",
            ageRange: "5-15 años",
            adjustable: "Sí",
            warranty: "2 años"
        }
    },
    {
        id: 19,
        name: "Prótesis de Pierna Inteligente",
        category: "pierna",
        type: "mioeléctrica",
        price: 52000,
        originalPrice: 58000,
        image: "https://images.pexels.com/photos/8376296/pexels-photo-8376296.jpeg?auto=compress&cs=tinysrgb&w=400",
        description: "Prótesis con sensores de equilibrio, GPS integrado y análisis de marcha.",
        features: ["Sensores Equilibrio", "GPS Integrado", "Análisis Marcha", "Conectividad"],
        rating: 4.7,
        reviews: 91,
        specifications: {
            weight: "2.3 kg",
            batteryLife: "30 horas",
            connectivity: "Bluetooth/WiFi",
            warranty: "4 años"
        }
    },
    {
        id: 20,
        name: "Kit de Herramientas Protésicas",
        category: "accesorios",
        type: "mecanica",
        price: 2500,
        originalPrice: 3200,
        image: "https://images.pexels.com/photos/8376297/pexels-photo-8376297.jpeg?auto=compress&cs=tinysrgb&w=400",
        description: "Kit completo de herramientas especializadas para mantenimiento de prótesis.",
        features: ["Kit Completo", "Herramientas Especializadas", "Manual Incluido", "Estuche"],
        rating: 4.4,
        reviews: 123,
        specifications: {
            weight: "1.2 kg",
            tools: "15 herramientas",
            case: "Resistente",
            warranty: "1 año"
        }
    }
];

// Featured products (subset of main products)
const featuredProducts = [
    products[3], // Mano Biónica Inteligente
    products[5], // Prótesis de Pierna con Rodilla Inteligente
    products[14] // Sistema Protésico Completo Brazo
];

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    // Hide loading screen after 2 seconds
    setTimeout(() => {
        document.getElementById('loadingScreen').classList.add('hidden');
    }, 2000);

    // Initialize components
    setupEventListeners();
    loadFeaturedProducts();
    loadProducts();
    updateCartUI();
    updateUserUI();
    
    // Initialize 3D viewer
    init3DViewer();
}

function setupEventListeners() {
    // Navigation
    document.getElementById('searchInput').addEventListener('input', handleSearch);
    
    // User menu
    document.getElementById('userBtn').addEventListener('click', toggleUserMenu);
    document.getElementById('loginBtn')?.addEventListener('click', () => showModal('loginModal'));
    document.getElementById('registerBtn')?.addEventListener('click', () => showModal('registerModal'));
    document.getElementById('profileBtn')?.addEventListener('click', () => showModal('profileModal'));
    document.getElementById('appointmentsBtn')?.addEventListener('click', () => showModal('appointmentsModal'));
    document.getElementById('ordersBtn')?.addEventListener('click', () => showModal('ordersModal'));
    document.getElementById('logoutBtn')?.addEventListener('click', logout);
    
    // Cart
    document.getElementById('cartBtn').addEventListener('click', () => showModal('cartModal'));
    document.getElementById('clearCart')?.addEventListener('click', clearCart);
    document.getElementById('checkout')?.addEventListener('click', () => showModal('checkoutModal'));
    
    // Filters
    document.getElementById('categoryFilter').addEventListener('change', applyFilters);
    document.getElementById('typeFilter').addEventListener('change', applyFilters);
    document.getElementById('priceFilter').addEventListener('change', applyFilters);
    document.getElementById('clearFilters').addEventListener('click', clearFilters);
    
    // View controls
    document.querySelectorAll('.view-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            document.querySelectorAll('.view-btn').forEach(b => b.classList.remove('active'));
            e.target.classList.add('active');
            toggleView(e.target.dataset.view);
        });
    });
    
    // Forms
    document.getElementById('appointmentForm')?.addEventListener('submit', handleAppointmentSubmit);
    document.getElementById('checkoutForm')?.addEventListener('submit', handleCheckoutSubmit);
    
    // Modal close buttons
    document.querySelectorAll('.close-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const modal = e.target.closest('.modal');
            hideModal(modal.id);
        });
    });
    
    // Close modals when clicking outside
    document.querySelectorAll('.modal').forEach(modal => {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                hideModal(modal.id);
            }
        });
    });
}

// Google Sign-In Handler
function handleCredentialResponse(response) {
    // Decode JWT token (in real app, verify on server)
    const payload = JSON.parse(atob(response.credential.split('.')[1]));
    
    currentUser = {
        id: payload.sub,
        name: payload.name,
        email: payload.email,
        picture: payload.picture,
        loginTime: new Date().toISOString()
    };
    
    localStorage.setItem('biotechUser', JSON.stringify(currentUser));
    updateUserUI();
    showNotification('¡Bienvenido! Has iniciado sesión correctamente.', 'success');
    hideModal('loginModal');
}

function updateUserUI() {
    const user = JSON.parse(localStorage.getItem('biotechUser')) || null;
    const userName = document.getElementById('userName');
    const userNameLarge = document.getElementById('userNameLarge');
    const userEmail = document.getElementById('userEmail');
    const loginBtn = document.getElementById('loginBtn');
    const registerBtn = document.getElementById('registerBtn');
    const profileBtn = document.getElementById('profileBtn');
    const appointmentsBtn = document.getElementById('appointmentsBtn');
    const ordersBtn = document.getElementById('ordersBtn');
    const logoutBtn = document.getElementById('logoutBtn');
    
    if (user) {
        currentUser = user;
        userName.textContent = user.name;
        userNameLarge.textContent = user.name;
        userEmail.textContent = user.email;
        
        loginBtn?.classList.add('hidden');
        registerBtn?.classList.add('hidden');
        profileBtn?.classList.remove('hidden');
        appointmentsBtn?.classList.remove('hidden');
        ordersBtn?.classList.remove('hidden');
        logoutBtn?.classList.remove('hidden');
    } else {
        userName.textContent = 'Invitado';
        userNameLarge.textContent = 'Invitado';
        userEmail.textContent = 'No autenticado';
        
        loginBtn?.classList.remove('hidden');
        registerBtn?.classList.remove('hidden');
        profileBtn?.classList.add('hidden');
        appointmentsBtn?.classList.add('hidden');
        ordersBtn?.classList.add('hidden');
        logoutBtn?.classList.add('hidden');
    }
}

function logout() {
    currentUser = null;
    localStorage.removeItem('biotechUser');
    updateUserUI();
    showNotification('Has cerrado sesión correctamente.', 'success');
    hideUserMenu();
}

function toggleUserMenu() {
    const userMenu = document.getElementById('userMenu');
    userMenu.classList.toggle('active');
}

function hideUserMenu() {
    const userMenu = document.getElementById('userMenu');
    userMenu.classList.remove('active');
}

// Products functionality
function loadFeaturedProducts() {
    const featuredGrid = document.getElementById('featuredGrid');
    featuredGrid.innerHTML = '';
    
    featuredProducts.forEach(product => {
        const productCard = createFeaturedProductCard(product);
        featuredGrid.appendChild(productCard);
    });
}

function createFeaturedProductCard(product) {
    const card = document.createElement('div');
    card.className = 'featured-card';
    
    const discount = Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100);
    
    card.innerHTML = `
        <div class="featured-badge">-${discount}%</div>
        <img src="${product.image}" alt="${product.name}" class="featured-image">
        <h3 class="featured-title">${product.name}</h3>
        <p class="featured-description">${product.description}</p>
        <div class="featured-price">$${product.price.toLocaleString()}</div>
        <button class="add-to-cart" onclick="addToCart(${product.id})">
            Agregar al Carrito
        </button>
    `;
    
    return card;
}

function loadProducts() {
    filteredProducts = [...products];
    renderProducts();
    renderPagination();
}

function renderProducts() {
    const productsGrid = document.getElementById('productsGrid');
    productsGrid.innerHTML = '';
    
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const pageProducts = filteredProducts.slice(startIndex, endIndex);
    
    pageProducts.forEach(product => {
        const productCard = createProductCard(product);
        productsGrid.appendChild(productCard);
    });
}

function createProductCard(product) {
    const card = document.createElement('div');
    card.className = 'product-card';
    
    const stars = '★'.repeat(Math.floor(product.rating)) + '☆'.repeat(5 - Math.floor(product.rating));
    
    card.innerHTML = `
        <img src="${product.image}" alt="${product.name}" class="product-image">
        <div class="product-info">
            <div class="product-category">${getCategoryName(product.category)}</div>
            <h3 class="product-title">${product.name}</h3>
            <p class="product-description">${product.description}</p>
            <div class="product-features">
                ${product.features.map(feature => `<span class="feature-tag">${feature}</span>`).join('')}
            </div>
            <div class="product-rating">
                <span class="stars">${stars}</span>
                <span class="rating-text">${product.rating} (${product.reviews} reseñas)</span>
            </div>
            <div class="product-price">$${product.price.toLocaleString()}</div>
            <div class="product-actions">
                <button class="add-to-cart" onclick="addToCart(${product.id})">
                    Agregar al Carrito
                </button>
                <button class="view-3d" onclick="showProductDetail(${product.id})">
                    Ver 3D
                </button>
            </div>
        </div>
    `;
    
    return card;
}

function getCategoryName(category) {
    const categories = {
        'brazo': 'Prótesis de Brazo',
        'pierna': 'Prótesis de Pierna',
        'mano': 'Prótesis de Mano',
        'pie': 'Prótesis de Pie',
        'dedos': 'Prótesis de Dedos',
        'facial': 'Prótesis Facial',
        'accesorios': 'Accesorios'
    };
    return categories[category] || category;
}

function showProductDetail(productId) {
    const product = products.find(p => p.id === productId);
    if (!product) return;
    
    const modal = document.getElementById('productModal');
    const title = document.getElementById('productModalTitle');
    const content = document.getElementById('productDetailContent');
    
    title.textContent = product.name;
    
    content.innerHTML = `
        <h3>${product.name}</h3>
        <p class="product-category">${getCategoryName(product.category)} - ${product.type}</p>
        <p>${product.description}</p>
        
        <h4>Características:</h4>
        <ul>
            ${product.features.map(feature => `<li>${feature}</li>`).join('')}
        </ul>
        
        <h4>Especificaciones:</h4>
        <ul>
            ${Object.entries(product.specifications).map(([key, value]) => 
                `<li><strong>${key}:</strong> ${value}</li>`
            ).join('')}
        </ul>
        
        <div class="product-price" style="margin-top: 1rem;">$${product.price.toLocaleString()}</div>
    `;
    
    // Setup 3D viewer for this product
    setup3DViewer(product);
    
    showModal('productModal');
}

// 3D Viewer functionality
let scene, camera, renderer, controls, currentModel;

function init3DViewer() {
    const container = document.getElementById('threejs-container');
    if (!container) return;
    
    // Scene setup
    scene = new THREE.Scene();
    scene.background = new THREE.Color(0x000000);
    
    // Camera setup
    camera = new THREE.PerspectiveCamera(75, container.clientWidth / container.clientHeight, 0.1, 1000);
    camera.position.set(0, 0, 5);
    
    // Renderer setup
    renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    
    container.appendChild(renderer.domElement);
    
    // Controls setup
    if (typeof THREE.OrbitControls !== 'undefined') {
        controls = new THREE.OrbitControls(camera, renderer.domElement);
        controls.enableDamping = true;
        controls.dampingFactor = 0.05;
    }
    
    // Lighting
    const ambientLight = new THREE.AmbientLight(0x404040, 0.6);
    scene.add(ambientLight);
    
    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
    directionalLight.position.set(10, 10, 5);
    directionalLight.castShadow = true;
    scene.add(directionalLight);
    
    // Control buttons
    document.getElementById('rotateBtn')?.addEventListener('click', () => {
        if (currentModel) {
            currentModel.rotation.y += 0.5;
        }
    });
    
    document.getElementById('resetBtn')?.addEventListener('click', () => {
        if (controls) {
            controls.reset();
        }
        if (currentModel) {
            currentModel.rotation.set(0, 0, 0);
        }
    });
    
    // Start render loop
    animate();
}

function setup3DViewer(product) {
    if (!scene) return;
    
    // Remove existing model
    if (currentModel) {
        scene.remove(currentModel);
    }
    
    // Create a simple 3D representation based on product category
    let geometry, material;
    
    switch (product.category) {
        case 'brazo':
            geometry = new THREE.CylinderGeometry(0.3, 0.4, 3, 8);
            material = new THREE.MeshPhongMaterial({ color: 0x00d4ff });
            break;
        case 'mano':
            geometry = new THREE.BoxGeometry(1, 0.3, 2);
            material = new THREE.MeshPhongMaterial({ color: 0x00d4ff });
            break;
        case 'pierna':
            geometry = new THREE.CylinderGeometry(0.4, 0.3, 4, 8);
            material = new THREE.MeshPhongMaterial({ color: 0x00d4ff });
            break;
        case 'pie':
            geometry = new THREE.BoxGeometry(2, 0.3, 0.8);
            material = new THREE.MeshPhongMaterial({ color: 0x00d4ff });
            break;
        default:
            geometry = new THREE.SphereGeometry(1, 16, 16);
            material = new THREE.MeshPhongMaterial({ color: 0x00d4ff });
    }
    
    currentModel = new THREE.Mesh(geometry, material);
    currentModel.castShadow = true;
    currentModel.receiveShadow = true;
    scene.add(currentModel);
    
    // Add some animation
    const animate3D = () => {
        if (currentModel) {
            currentModel.rotation.y += 0.01;
        }
    };
    
    // Start product-specific animation
    const interval = setInterval(animate3D, 16);
    
    // Clear animation when modal closes
    const modal = document.getElementById('productModal');
    const observer = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
            if (mutation.attributeName === 'style' && !modal.classList.contains('show')) {
                clearInterval(interval);
                observer.disconnect();
            }
        });
    });
    observer.observe(modal, { attributes: true });
}

function animate() {
    requestAnimationFrame(animate);
    
    if (controls) {
        controls.update();
    }
    
    if (renderer && scene && camera) {
        renderer.render(scene, camera);
    }
}

// Cart functionality
function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    if (!product) return;
    
    const existingItem = cart.find(item => item.id === productId);
    
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({
            ...product,
            quantity: 1,
            addedAt: new Date().toISOString()
        });
    }
    
    localStorage.setItem('biotechCart', JSON.stringify(cart));
    updateCartUI();
    showNotification(`${product.name} agregado al carrito`, 'success');
}

function removeFromCart(productId) {
    cart = cart.filter(item => item.id !== productId);
    localStorage.setItem('biotechCart', JSON.stringify(cart));
    updateCartUI();
    renderCartItems();
}

function updateQuantity(productId, change) {
    const item = cart.find(item => item.id === productId);
    if (!item) return;
    
    item.quantity += change;
    
    if (item.quantity <= 0) {
        removeFromCart(productId);
        return;
    }
    
    localStorage.setItem('biotechCart', JSON.stringify(cart));
    updateCartUI();
    renderCartItems();
}

function clearCart() {
    cart = [];
    localStorage.setItem('biotechCart', JSON.stringify(cart));
    updateCartUI();
    renderCartItems();
    showNotification('Carrito vaciado', 'success');
}

function updateCartUI() {
    const cartCount = document.getElementById('cartCount');
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    cartCount.textContent = totalItems;
    
    // Update cart modal when it's open
    if (document.getElementById('cartModal').classList.contains('show')) {
        renderCartItems();
    }
}

function renderCartItems() {
    const cartItems = document.getElementById('cartItems');
    const cartSubtotal = document.getElementById('cartSubtotal');
    const cartTotal = document.getElementById('cartTotal');
    
    if (cart.length === 0) {
        cartItems.innerHTML = `
            <div class="empty-cart">
                <h3>Tu carrito está vacío</h3>
                <p>Agrega algunos productos para comenzar</p>
            </div>
        `;
        cartSubtotal.textContent = '$0.00';
        cartTotal.textContent = '$500.00'; // Consultation fee only
        return;
    }
    
    cartItems.innerHTML = '';
    let subtotal = 0;
    
    cart.forEach(item => {
        subtotal += item.price * item.quantity;
        
        const cartItem = document.createElement('div');
        cartItem.className = 'cart-item';
        cartItem.innerHTML = `
            <div class="cart-item-info">
                <img src="${item.image}" alt="${item.name}" class="cart-item-image">
                <div class="cart-item-details">
                    <div class="cart-item-name">${item.name}</div>
                    <div class="cart-item-category">${getCategoryName(item.category)}</div>
                    <div class="cart-item-price">$${item.price.toLocaleString()}</div>
                </div>
            </div>
            <div class="cart-item-quantity">
                <button class="quantity-btn" onclick="updateQuantity(${item.id}, -1)">-</button>
                <span class="quantity-display">${item.quantity}</span>
                <button class="quantity-btn" onclick="updateQuantity(${item.id}, 1)">+</button>
            </div>
            <button class="remove-item" onclick="removeFromCart(${item.id})">Eliminar</button>
        `;
        
        cartItems.appendChild(cartItem);
    });
    
    const consultationFee = 500;
    const total = subtotal + consultationFee;
    
    cartSubtotal.textContent = `$${subtotal.toLocaleString()}`;
    cartTotal.textContent = `$${total.toLocaleString()}`;
}

// Appointments functionality
function handleAppointmentSubmit(e) {
    e.preventDefault();
    
    if (!currentUser) {
        showNotification('Debes iniciar sesión para agendar una cita', 'error');
        return;
    }
    
    const formData = new FormData(e.target);
    const appointment = {
        id: Date.now(),
        patientName: formData.get('patientName') || document.getElementById('patientName').value,
        patientPhone: formData.get('patientPhone') || document.getElementById('patientPhone').value,
        patientEmail: formData.get('patientEmail') || document.getElementById('patientEmail').value,
        appointmentDate: formData.get('appointmentDate') || document.getElementById('appointmentDate').value,
        appointmentTime: formData.get('appointmentTime') || document.getElementById('appointmentTime').value,
        prosthesisType: formData.get('prosthesisType') || document.getElementById('prosthesisType').value,
        medicalHistory: formData.get('medicalHistory') || document.getElementById('medicalHistory').value,
        status: 'scheduled',
        createdAt: new Date().toISOString(),
        userId: currentUser.id
    };
    
    appointments.push(appointment);
    localStorage.setItem('biotechAppointments', JSON.stringify(appointments));
    
    showNotification('Cita agendada exitosamente', 'success');
    e.target.reset();
    
    // Update profile stats
    updateProfileStats();
}

// Checkout functionality
function handleCheckoutSubmit(e) {
    e.preventDefault();
    
    if (!currentUser) {
        showNotification('Debes iniciar sesión para realizar un pedido', 'error');
        return;
    }
    
    if (cart.length === 0) {
        showNotification('Tu carrito está vacío', 'error');
        return;
    }
    
    const formData = new FormData(e.target);
    const order = {
        id: Date.now(),
        orderNumber: `BTP-${Date.now().toString().slice(-6)}`,
        patientName: formData.get('patientFullName') || document.getElementById('patientFullName').value,
        patientAge: formData.get('patientAge') || document.getElementById('patientAge').value,
        medicalCondition: formData.get('medicalCondition') || document.getElementById('medicalCondition').value,
        doctorName: formData.get('doctorName') || document.getElementById('doctorName').value,
        insuranceProvider: formData.get('insuranceProvider') || document.getElementById('insuranceProvider').value,
        paymentMethod: document.querySelector('input[name="payment"]:checked').value,
        items: [...cart],
        subtotal: cart.reduce((sum, item) => sum + (item.price * item.quantity), 0),
        consultationFee: 500,
        total: cart.reduce((sum, item) => sum + (item.price * item.quantity), 0) + 500,
        status: 'processing',
        createdAt: new Date().toISOString(),
        userId: currentUser.id
    };
    
    orders.push(order);
    localStorage.setItem('biotechOrders', JSON.stringify(orders));
    
    // Clear cart
    clearCart();
    
    showNotification(`Pedido ${order.orderNumber} creado exitosamente`, 'success');
    hideModal('checkoutModal');
    
    // Update profile stats
    updateProfileStats();
}

// Search functionality
function handleSearch(e) {
    const query = e.target.value.toLowerCase();
    
    if (query === '') {
        filteredProducts = [...products];
    } else {
        filteredProducts = products.filter(product => 
            product.name.toLowerCase().includes(query) ||
            product.description.toLowerCase().includes(query) ||
            product.features.some(feature => feature.toLowerCase().includes(query))
        );
    }
    
    currentPage = 1;
    renderProducts();
    renderPagination();
}

// Filter functionality
function applyFilters() {
    const categoryFilter = document.getElementById('categoryFilter').value;
    const typeFilter = document.getElementById('typeFilter').value;
    const priceFilter = document.getElementById('priceFilter').value;
    
    filteredProducts = products.filter(product => {
        let matches = true;
        
        if (categoryFilter && product.category !== categoryFilter) {
            matches = false;
        }
        
        if (typeFilter && product.type !== typeFilter) {
            matches = false;
        }
        
        if (priceFilter) {
            const [min, max] = priceFilter.split('-').map(p => p.replace('+', ''));
            const minPrice = parseInt(min);
            const maxPrice = max ? parseInt(max) : Infinity;
            
            if (product.price < minPrice || product.price > maxPrice) {
                matches = false;
            }
        }
        
        return matches;
    });
    
    currentPage = 1;
    renderProducts();
    renderPagination();
}

function clearFilters() {
    document.getElementById('categoryFilter').value = '';
    document.getElementById('typeFilter').value = '';
    document.getElementById('priceFilter').value = '';
    document.getElementById('searchInput').value = '';
    
    filteredProducts = [...products];
    currentPage = 1;
    renderProducts();
    renderPagination();
}

// View toggle functionality
function toggleView(view) {
    const productsGrid = document.getElementById('productsGrid');
    
    if (view === 'list') {
        productsGrid.classList.add('list-view');
        productsGrid.querySelectorAll('.product-card').forEach(card => {
            card.classList.add('list-view');
        });
    } else {
        productsGrid.classList.remove('list-view');
        productsGrid.querySelectorAll('.product-card').forEach(card => {
            card.classList.remove('list-view');
        });
    }
}

// Pagination functionality
function renderPagination() {
    const pagination = document.getElementById('pagination');
    const totalPages = Math.ceil(filteredProducts.length / itemsPerPage);
    
    if (totalPages <= 1) {
        pagination.innerHTML = '';
        return;
    }
    
    let paginationHTML = '';
    
    // Previous button
    paginationHTML += `
        <button class="pagination-btn" ${currentPage === 1 ? 'disabled' : ''} 
                onclick="changePage(${currentPage - 1})">‹</button>
    `;
    
    // Page numbers
    for (let i = 1; i <= totalPages; i++) {
        if (i === 1 || i === totalPages || (i >= currentPage - 2 && i <= currentPage + 2)) {
            paginationHTML += `
                <button class="pagination-btn ${i === currentPage ? 'active' : ''}" 
                        onclick="changePage(${i})">${i}</button>
            `;
        } else if (i === currentPage - 3 || i === currentPage + 3) {
            paginationHTML += '<span class="pagination-ellipsis">...</span>';
        }
    }
    
    // Next button
    paginationHTML += `
        <button class="pagination-btn" ${currentPage === totalPages ? 'disabled' : ''} 
                onclick="changePage(${currentPage + 1})">›</button>
    `;
    
    pagination.innerHTML = paginationHTML;
}

function changePage(page) {
    const totalPages = Math.ceil(filteredProducts.length / itemsPerPage);
    
    if (page < 1 || page > totalPages) return;
    
    currentPage = page;
    renderProducts();
    renderPagination();
    
    // Scroll to products section
    document.getElementById('products').scrollIntoView({ behavior: 'smooth' });
}

// Modal functionality
function showModal(modalId) {
    const modal = document.getElementById(modalId);
    modal.classList.add('show');
    modal.style.display = 'flex';
    
    // Load modal-specific content
    if (modalId === 'cartModal') {
        renderCartItems();
    } else if (modalId === 'checkoutModal') {
        renderCheckoutItems();
    } else if (modalId === 'profileModal') {
        loadProfileData();
    } else if (modalId === 'appointmentsModal') {
        loadAppointments();
    } else if (modalId === 'ordersModal') {
        loadOrders();
    }
}

function hideModal(modalId) {
    const modal = document.getElementById(modalId);
    modal.classList.remove('show');
    modal.style.display = 'none';
}

// Profile functionality
function loadProfileData() {
    if (!currentUser) return;
    
    document.getElementById('profileName').value = currentUser.name || '';
    document.getElementById('profileEmail').value = currentUser.email || '';
    document.getElementById('profilePhone').value = currentUser.phone || '';
    
    updateProfileStats();
}

function updateProfileStats() {
    const userOrders = orders.filter(order => order.userId === currentUser?.id);
    const userAppointments = appointments.filter(apt => apt.userId === currentUser?.id);
    const totalSpent = userOrders.reduce((sum, order) => sum + order.total, 0);
    
    document.getElementById('totalOrders').textContent = userOrders.length;
    document.getElementById('totalAppointments').textContent = userAppointments.length;
    document.getElementById('memberSince').textContent = new Date(currentUser?.loginTime || Date.now()).getFullYear();
}

function loadAppointments() {
    const appointmentsList = document.getElementById('appointmentsList');
    const userAppointments = appointments.filter(apt => apt.userId === currentUser?.id);
    
    if (userAppointments.length === 0) {
        appointmentsList.innerHTML = `
            <div class="empty-cart">
                <h3>No tienes citas agendadas</h3>
                <p>Agenda tu primera consulta médica</p>
            </div>
        `;
        return;
    }
    
    appointmentsList.innerHTML = '';
    
    userAppointments.forEach(appointment => {
        const appointmentCard = document.createElement('div');
        appointmentCard.className = 'appointment-card';
        appointmentCard.innerHTML = `
            <div class="appointment-header">
                <div class="appointment-number">Cita #${appointment.id.toString().slice(-6)}</div>
                <div class="appointment-date">${new Date(appointment.appointmentDate).toLocaleDateString()}</div>
                <div class="appointment-status ${appointment.status}">${appointment.status}</div>
            </div>
            <div class="appointment-details">
                <div class="appointment-detail">
                    <span>Tipo:</span>
                    <span>${getCategoryName(appointment.prosthesisType)}</span>
                </div>
                <div class="appointment-detail">
                    <span>Hora:</span>
                    <span>${appointment.appointmentTime}</span>
                </div>
                <div class="appointment-detail">
                    <span>Teléfono:</span>
                    <span>${appointment.patientPhone}</span>
                </div>
            </div>
        `;
        appointmentsList.appendChild(appointmentCard);
    });
}

function loadOrders() {
    const ordersList = document.getElementById('ordersList');
    const userOrders = orders.filter(order => order.userId === currentUser?.id);
    
    if (userOrders.length === 0) {
        ordersList.innerHTML = `
            <div class="empty-cart">
                <h3>No tienes pedidos</h3>
                <p>Realiza tu primer pedido</p>
            </div>
        `;
        return;
    }
    
    ordersList.innerHTML = '';
    
    userOrders.forEach(order => {
        const orderCard = document.createElement('div');
        orderCard.className = 'order-card';
        orderCard.innerHTML = `
            <div class="order-header">
                <div class="order-number">Pedido ${order.orderNumber}</div>
                <div class="order-date">${new Date(order.createdAt).toLocaleDateString()}</div>
                <div class="order-status ${order.status}">${order.status}</div>
            </div>
            <div class="order-items">
                ${order.items.map(item => `
                    <div class="order-item">
                        <span>${item.name} x${item.quantity}</span>
                        <span>$${(item.price * item.quantity).toLocaleString()}</span>
                    </div>
                `).join('')}
            </div>
            <div class="order-total">Total: $${order.total.toLocaleString()}</div>
        `;
        ordersList.appendChild(orderCard);
    });
}

function renderCheckoutItems() {
    const checkoutItems = document.getElementById('checkoutItems');
    const checkoutSubtotal = document.getElementById('checkoutSubtotal');
    const checkoutTotal = document.getElementById('checkoutTotal');
    
    if (cart.length === 0) return;
    
    checkoutItems.innerHTML = '';
    let subtotal = 0;
    
    cart.forEach(item => {
        subtotal += item.price * item.quantity;
        
        const checkoutItem = document.createElement('div');
        checkoutItem.className = 'checkout-item';
        checkoutItem.innerHTML = `
            <span>${item.name} x${item.quantity}</span>
            <span>$${(item.price * item.quantity).toLocaleString()}</span>
        `;
        checkoutItems.appendChild(checkoutItem);
    });
    
    const consultationFee = 500;
    const total = subtotal + consultationFee;
    
    checkoutSubtotal.textContent = `$${subtotal.toLocaleString()}`;
    checkoutTotal.textContent = `$${total.toLocaleString()}`;
}

// Notification system
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    const container = document.getElementById('notifications');
    container.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        notification.remove();
    }, 5000);
}

// Utility functions
function formatCurrency(amount) {
    return new Intl.NumberFormat('es-US', {
        style: 'currency',
        currency: 'USD'
    }).format(amount);
}

function formatDate(dateString) {
    return new Date(dateString).toLocaleDateString('es-ES', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

// Close user menu when clicking outside
document.addEventListener('click', (e) => {
    const userMenu = document.getElementById('userMenu');
    if (!userMenu.contains(e.target)) {
        hideUserMenu();
    }
});

// Handle window resize for 3D viewer
window.addEventListener('resize', () => {
    if (renderer && camera) {
        const container = document.getElementById('threejs-container');
        if (container) {
            camera.aspect = container.clientWidth / container.clientHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(container.clientWidth, container.clientHeight);
        }
    }
});

// Export functions for global access
window.addToCart = addToCart;
window.removeFromCart = removeFromCart;
window.updateQuantity = updateQuantity;
window.showProductDetail = showProductDetail;
window.changePage = changePage;
window.handleCredentialResponse = handleCredentialResponse;