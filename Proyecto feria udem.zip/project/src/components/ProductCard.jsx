import React from 'react'
import { ShoppingCart, Eye } from 'lucide-react'
import { useCart } from '../context/CartContext'
import { useNotification } from '../context/NotificationContext'

const ProductCard = ({ product, onViewDetails }) => {
  const { addToCart } = useCart()
  const { showNotification } = useNotification()

  const handleAddToCart = () => {
    addToCart(product)
    showNotification(`${product.name} agregado al carrito`, 'success')
  }

  const getCategoryName = (category) => {
    const categories = {
      'brazo': 'Prótesis de Brazo',
      'pierna': 'Prótesis de Pierna',
      'mano': 'Prótesis de Mano',
      'pie': 'Prótesis de Pie',
      'dedos': 'Prótesis de Dedos',
      'facial': 'Prótesis Facial',
      'accesorios': 'Accesorios'
    }
    return categories[category] || category
  }

  const stars = '★'.repeat(Math.floor(product.rating)) + '☆'.repeat(5 - Math.floor(product.rating))

  return (
    <div className="product-card">
      <img 
        src={product.image} 
        alt={product.name} 
        className="product-image"
      />
      <div className="product-info">
        <div className="product-category">{getCategoryName(product.category)}</div>
        <h3 className="product-title">{product.name}</h3>
        <p className="product-description">{product.description}</p>
        
        <div className="product-features">
          {product.features.map((feature, index) => (
            <span key={index} className="feature-tag">{feature}</span>
          ))}
        </div>
        
        <div className="product-rating">
          <span className="stars">{stars}</span>
          <span className="rating-text">{product.rating} ({product.reviews} reseñas)</span>
        </div>
        
        <div className="product-price">${product.price.toLocaleString()}</div>
        
        <div className="product-actions">
          <button 
            className="add-to-cart"
            onClick={handleAddToCart}
          >
            <ShoppingCart size={16} />
            Agregar al Carrito
          </button>
          <button 
            className="view-3d"
            onClick={() => onViewDetails(product)}
          >
            <Eye size={16} />
            Ver 3D
          </button>
        </div>
      </div>
    </div>
  )
}

export default ProductCard