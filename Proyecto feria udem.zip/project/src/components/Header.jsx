import React, { useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { Search, ShoppingCart, User, Menu, X } from 'lucide-react'
import { useAuth } from '../context/AuthContext'
import { useCart } from '../context/CartContext'
import AuthModal from './AuthModal'
import CartModal from './CartModal'

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false)
  const [isCartModalOpen, setIsCartModalOpen] = useState(false)
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  
  const { user, logout } = useAuth()
  const { getTotalItems } = useCart()
  const location = useLocation()

  const navItems = [
    { name: 'Inicio', path: '/' },
    { name: 'Productos', path: '/products' },
    { name: 'Citas', path: '/appointments' },
    { name: 'Nosotros', path: '/about' }
  ]

  const handleLogout = () => {
    logout()
    setIsUserMenuOpen(false)
  }

  return (
    <>
      <header className="header compact">
        <nav className="nav">
          <div className="nav-brand">
            <Link to="/">
              <h1>BioTech Pro</h1>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <ul className="nav-menu desktop-only">
            {navItems.map((item) => (
              <li key={item.path}>
                <Link 
                  to={item.path}
                  className={location.pathname === item.path ? 'active' : ''}
                >
                  {item.name}
                </Link>
              </li>
            ))}
          </ul>

          {/* Search Bar */}
          <div className="nav-search">
            <input
              type="text"
              placeholder="Buscar prótesis..."
              className="search-input"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <button className="search-btn">
              <Search size={16} />
            </button>
          </div>

          {/* Actions */}
          <div className="nav-actions">
            {/* User Menu */}
            <div className="user-menu">
              <button 
                className="user-btn"
                onClick={() => user ? setIsUserMenuOpen(!isUserMenuOpen) : setIsAuthModalOpen(true)}
              >
                <User className="user-avatar" />
                <span className="user-name">{user ? user.name : 'Invitado'}</span>
              </button>

              {user && isUserMenuOpen && (
                <div className="user-dropdown active">
                  <div className="user-info">
                    <div className="user-avatar-large">
                      <img src={user.picture} alt={user.name} />
                    </div>
                    <div>
                      <div className="user-name-large">{user.name}</div>
                      <div className="user-email">{user.email}</div>
                    </div>
                  </div>
                  <Link to="/profile" className="dropdown-btn" onClick={() => setIsUserMenuOpen(false)}>
                    Mi Perfil
                  </Link>
                  <Link to="/appointments" className="dropdown-btn" onClick={() => setIsUserMenuOpen(false)}>
                    Mis Citas
                  </Link>
                  <button className="dropdown-btn" onClick={handleLogout}>
                    Cerrar Sesión
                  </button>
                </div>
              )}
            </div>

            {/* Cart */}
            <button 
              className="cart-btn"
              onClick={() => setIsCartModalOpen(true)}
            >
              <ShoppingCart size={18} />
              Carrito
              <span id="cartCount">{getTotalItems()}</span>
            </button>

            {/* Mobile Menu Toggle */}
            <button 
              className="mobile-menu-btn mobile-only"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </nav>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="mobile-menu">
            {navItems.map((item) => (
              <Link 
                key={item.path}
                to={item.path}
                className={`mobile-menu-item ${location.pathname === item.path ? 'active' : ''}`}
                onClick={() => setIsMenuOpen(false)}
              >
                {item.name}
              </Link>
            ))}
          </div>
        )}
      </header>

      {/* Modals */}
      <AuthModal 
        isOpen={isAuthModalOpen} 
        onClose={() => setIsAuthModalOpen(false)} 
      />
      <CartModal 
        isOpen={isCartModalOpen} 
        onClose={() => setIsCartModalOpen(false)} 
      />
    </>
  )
}

export default Header