import React from 'react'
import { X, CheckCircle, AlertCircle, AlertTriangle } from 'lucide-react'
import { useNotification } from '../context/NotificationContext'

const Notifications = () => {
  const { notifications, removeNotification } = useNotification()

  const getIcon = (type) => {
    switch (type) {
      case 'success':
        return <CheckCircle size={20} />
      case 'error':
        return <AlertCircle size={20} />
      case 'warning':
        return <AlertTriangle size={20} />
      default:
        return <CheckCircle size={20} />
    }
  }

  return (
    <div className="notifications-container">
      {notifications.map((notification) => (
        <div 
          key={notification.id} 
          className={`notification ${notification.type}`}
        >
          <div className="notification-content">
            {getIcon(notification.type)}
            <span>{notification.message}</span>
          </div>
          <button 
            className="notification-close"
            onClick={() => removeNotification(notification.id)}
          >
            <X size={16} />
          </button>
        </div>
      ))}
    </div>
  )
}

export default Notifications