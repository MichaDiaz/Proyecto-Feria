import React from 'react'
import { X, Plus, Minus, Trash2, ShoppingBag } from 'lucide-react'
import { useCart } from '../context/CartContext'
import { useAuth } from '../context/AuthContext'
import { useNotification } from '../context/NotificationContext'

const CartModal = ({ isOpen, onClose }) => {
  const { cart, updateQuantity, removeFromCart, clearCart, getTotalPrice } = useCart()
  const { user } = useAuth()
  const { showNotification } = useNotification()

  const handleCheckout = () => {
    if (!user) {
      showNotification('Debes iniciar sesión para realizar una compra', 'error')
      return
    }
    
    if (cart.length === 0) {
      showNotification('Tu carrito está vacío', 'error')
      return
    }

    // Simulate checkout process
    const orderNumber = `BTP-${Date.now().toString().slice(-6)}`
    showNotification(`Pedido ${orderNumber} creado exitosamente`, 'success')
    clearCart()
    onClose()
  }

  if (!isOpen) return null

  return (
    <div className="modal show">
      <div className="modal-content large">
        <div className="modal-header">
          <h2>
            <ShoppingBag size={24} />
            Carrito de Compras
          </h2>
          <button className="close-btn" onClick={onClose}>
            <X size={24} />
          </button>
        </div>

        <div className="modal-body">
          {cart.length === 0 ? (
            <div className="empty-cart">
              <ShoppingBag size={64} />
              <h3>Tu carrito está vacío</h3>
              <p>Agrega algunos productos para comenzar</p>
            </div>
          ) : (
            <>
              <div className="cart-items">
                {cart.map((item) => (
                  <div key={item.id} className="cart-item">
                    <div className="cart-item-info">
                      <img 
                        src={item.image} 
                        alt={item.name} 
                        className="cart-item-image"
                      />
                      <div className="cart-item-details">
                        <div className="cart-item-name">{item.name}</div>
                        <div className="cart-item-category">{item.category}</div>
                        <div className="cart-item-price">
                          ${item.price.toLocaleString()}
                        </div>
                      </div>
                    </div>
                    
                    <div className="cart-item-quantity">
                      <button 
                        className="quantity-btn"
                        onClick={() => updateQuantity(item.id, -1)}
                      >
                        <Minus size={16} />
                      </button>
                      <span className="quantity-display">{item.quantity}</span>
                      <button 
                        className="quantity-btn"
                        onClick={() => updateQuantity(item.id, 1)}
                      >
                        <Plus size={16} />
                      </button>
                    </div>
                    
                    <button 
                      className="remove-item"
                      onClick={() => removeFromCart(item.id)}
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                ))}
              </div>

              <div className="cart-summary">
                <div className="cart-totals">
                  <div className="total-line">
                    <span>Subtotal:</span>
                    <span>${getTotalPrice().toLocaleString()}</span>
                  </div>
                  <div className="total-line">
                    <span>Consulta médica:</span>
                    <span>$500</span>
                  </div>
                  <div className="total-line total">
                    <span>Total:</span>
                    <span>${(getTotalPrice() + 500).toLocaleString()}</span>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>

        {cart.length > 0 && (
          <div className="modal-footer">
            <button 
              className="btn-secondary"
              onClick={clearCart}
            >
              Vaciar Carrito
            </button>
            <button 
              className="btn-primary"
              onClick={handleCheckout}
            >
              Proceder al Pago
            </button>
          </div>
        )}
      </div>
    </div>
  )
}

export default CartModal