import React, { useRef, useEffect } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { OrbitControls, PerspectiveCamera } from '@react-three/drei'
import * as THREE from 'three'

const ProductMesh = ({ category }) => {
  const meshRef = useRef()

  useFrame(() => {
    if (meshRef.current) {
      meshRef.current.rotation.y += 0.01
    }
  })

  const getGeometry = () => {
    switch (category) {
      case 'brazo':
        return <cylinderGeometry args={[0.3, 0.4, 3, 8]} />
      case 'mano':
        return <boxGeometry args={[1, 0.3, 2]} />
      case 'pierna':
        return <cylinderGeometry args={[0.4, 0.3, 4, 8]} />
      case 'pie':
        return <boxGeometry args={[2, 0.3, 0.8]} />
      default:
        return <sphereGeometry args={[1, 16, 16]} />
    }
  }

  return (
    <mesh ref={meshRef} castShadow receiveShadow>
      {getGeometry()}
      <meshPhongMaterial color="#00d4ff" />
    </mesh>
  )
}

const Product3DViewer = ({ product }) => {
  return (
    <div className="threejs-viewer">
      <Canvas shadows>
        <PerspectiveCamera makeDefault position={[0, 0, 5]} />
        <OrbitControls enableDamping dampingFactor={0.05} />
        
        <ambientLight intensity={0.6} />
        <directionalLight 
          position={[10, 10, 5]} 
          intensity={0.8} 
          castShadow 
        />
        
        <ProductMesh category={product.category} />
        
        <mesh receiveShadow rotation={[-Math.PI / 2, 0, 0]} position={[0, -2, 0]}>
          <planeGeometry args={[10, 10]} />
          <shadowMaterial opacity={0.3} />
        </mesh>
      </Canvas>
      
      <div className="viewer-info">
        <p>Usa el mouse para rotar y hacer zoom</p>
      </div>
    </div>
  )
}

export default Product3DViewer