import React from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { AuthProvider } from './context/AuthContext'
import { CartProvider } from './context/CartContext'
import { NotificationProvider } from './context/NotificationContext'
import Header from './components/Header'
import Home from './pages/Home'
import Products from './pages/Products'
import Appointments from './pages/Appointments'
import About from './pages/About'
import Profile from './pages/Profile'
import LoadingScreen from './components/LoadingScreen'
import Notifications from './components/Notifications'
import './style.css'

function App() {
  return (
    <AuthProvider>
      <CartProvider>
        <NotificationProvider>
          <Router>
            <div className="App">
              <LoadingScreen />
              <Header />
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/products" element={<Products />} />
                <Route path="/appointments" element={<Appointments />} />
                <Route path="/about" element={<About />} />
                <Route path="/profile" element={<Profile />} />
              </Routes>
              <Notifications />
            </div>
          </Router>
        </NotificationProvider>
      </CartProvider>
    </AuthProvider>
  )
}

export default App