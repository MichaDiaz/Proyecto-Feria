// Prosthetic products database with real images from Pexels
export const products = [
    // Arm Prosthetics
    {
        id: 1,
        name: "Prótesis Mioeléctrica de Brazo Avanzada",
        category: "brazo",
        type: "mioeléctrica",
        price: 25000,
        originalPrice: 30000,
        image: "https://images.pexels.com/photos/8376277/pexels-photo-8376277.jpeg?auto=compress&cs=tinysrgb&w=400",
        description: "Prótesis de brazo con control mioeléctrico avanzado, múltiples grados de libertad y feedback táctil.",
        features: ["Control Mioeléctrico", "Feedback Táctil", "Resistente al Agua", "Batería 12h"],
        rating: 4.9,
        reviews: 127,
        specifications: {
            weight: "1.2 kg",
            batteryLife: "12 horas",
            material: "Titanio y Carbono",
            warranty: "3 años"
        }
    },
    {
        id: 2,
        name: "Prótesis Mecánica de Brazo Deportiva",
        category: "brazo",
        type: "deportiva",
        price: 15000,
        originalPrice: 18000,
        image: "https://images.pexels.com/photos/8376278/pexels-photo-8376278.jpeg?auto=compress&cs=tinysrgb&w=400",
        description: "Diseñada para actividades deportivas con materiales ultraligeros y resistentes.",
        features: ["Ultraligera", "Resistente Impactos", "Ajuste Rápido", "Ventilación"],
        rating: 4.7,
        reviews: 89,
        specifications: {
            weight: "0.8 kg",
            material: "Fibra de Carbono",
            resistance: "IP67",
            warranty: "2 años"
        }
    },
    {
        id: 3,
        name: "Prótesis Cosmética de Brazo Premium",
        category: "brazo",
        type: "cosmética",
        price: 8000,
        originalPrice: 10000,
        image: "https://images.pexels.com/photos/8376280/pexels-photo-8376280.jpeg?auto=compress&cs=tinysrgb&w=400",
        description: "Prótesis cosmética con apariencia ultra-realista y materiales biocompatibles.",
        features: ["Ultra-realista", "Biocompatible", "Personalizable", "Ligera"],
        rating: 4.6,
        reviews: 156,
        specifications: {
            weight: "0.6 kg",
            material: "Silicona Médica",
            customization: "100% Personalizable",
            warranty: "2 años"
        }
    },

    // Hand Prosthetics
    {
        id: 4,
        name: "Mano Biónica Inteligente",
        category: "mano",
        type: "mioeléctrica",
        price: 35000,
        originalPrice: 40000,
        image: "https://images.pexels.com/photos/8376281/pexels-photo-8376281.jpeg?auto=compress&cs=tinysrgb&w=400",
        description: "Mano protésica con IA integrada, 15 patrones de agarre y control intuitivo.",
        features: ["IA Integrada", "15 Patrones Agarre", "Control Intuitivo", "Sensores Presión"],
        rating: 4.9,
        reviews: 203,
        specifications: {
            weight: "0.5 kg",
            batteryLife: "16 horas",
            gripPatterns: "15 patrones",
            warranty: "5 años"
        }
    },
    {
        id: 5,
        name: "Prótesis de Mano Mecánica Profesional",
        category: "mano",
        type: "mecanica",
        price: 12000,
        originalPrice: 15000,
        image: "https://images.pexels.com/photos/8376282/pexels-photo-8376282.jpeg?auto=compress&cs=tinysrgb&w=400",
        description: "Mano mecánica de alta precisión para uso profesional y actividades detalladas.",
        features: ["Alta Precisión", "Control Cable", "Durabilidad", "Mantenimiento Fácil"],
        rating: 4.5,
        reviews: 134,
        specifications: {
            weight: "0.4 kg",
            material: "Aleación Titanio",
            precision: "±0.1mm",
            warranty: "3 años"
        }
    },

    // Leg Prosthetics
    {
        id: 6,
        name: "Prótesis de Pierna con Rodilla Inteligente",
        category: "pierna",
        type: "mioeléctrica",
        price: 45000,
        originalPrice: 50000,
        image: "https://images.pexels.com/photos/8376283/pexels-photo-8376283.jpeg?auto=compress&cs=tinysrgb&w=400",
        description: "Prótesis de pierna con rodilla microcontrolada y adaptación automática al terreno.",
        features: ["Rodilla Inteligente", "Adaptación Terreno", "Amortiguación", "Control App"],
        rating: 4.8,
        reviews: 167,
        specifications: {
            weight: "2.1 kg",
            batteryLife: "24 horas",
            maxWeight: "120 kg",
            warranty: "4 años"
        }
    },
    {
        id: 7,
        name: "Prótesis Deportiva de Pierna Running",
        category: "pierna",
        type: "deportiva",
        price: 28000,
        originalPrice: 32000,
        image: "https://images.pexels.com/photos/8376284/pexels-photo-8376284.jpeg?auto=compress&cs=tinysrgb&w=400",
        description: "Diseñada específicamente para corredores con retorno de energía optimizado.",
        features: ["Retorno Energía", "Ultraligera", "Aerodinámica", "Absorción Impacto"],
        rating: 4.7,
        reviews: 98,
        specifications: {
            weight: "1.3 kg",
            material: "Fibra Carbono",
            energyReturn: "85%",
            warranty: "3 años"
        }
    },
    {
        id: 8,
        name: "Prótesis Mecánica de Pierna Estándar",
        category: "pierna",
        type: "mecanica",
        price: 18000,
        originalPrice: 22000,
        image: "https://images.pexels.com/photos/8376285/pexels-photo-8376285.jpeg?auto=compress&cs=tinysrgb&w=400",
        description: "Prótesis mecánica confiable para uso diario con excelente durabilidad.",
        features: ["Uso Diario", "Durabilidad", "Ajuste Preciso", "Mantenimiento Mínimo"],
        rating: 4.4,
        reviews: 145,
        specifications: {
            weight: "1.8 kg",
            material: "Aleación Aluminio",
            maxWeight: "100 kg",
            warranty: "3 años"
        }
    },

    // Foot Prosthetics
    {
        id: 9,
        name: "Pie Protésico con Tobillo Dinámico",
        category: "pie",
        type: "mioeléctrica",
        price: 22000,
        originalPrice: 26000,
        image: "https://images.pexels.com/photos/8376286/pexels-photo-8376286.jpeg?auto=compress&cs=tinysrgb&w=400",
        description: "Pie protésico con tobillo motorizado para movimiento natural y adaptativo.",
        features: ["Tobillo Motorizado", "Movimiento Natural", "Sensores Terreno", "App Control"],
        rating: 4.6,
        reviews: 112,
        specifications: {
            weight: "0.9 kg",
            batteryLife: "20 horas",
            angleRange: "30°",
            warranty: "3 años"
        }
    },
    {
        id: 10,
        name: "Pie Deportivo de Alto Rendimiento",
        category: "pie",
        type: "deportiva",
        price: 16000,
        originalPrice: 19000,
        image: "https://images.pexels.com/photos/8376287/pexels-photo-8376287.jpeg?auto=compress&cs=tinysrgb&w=400",
        description: "Pie protésico optimizado para deportes con máximo retorno de energía.",
        features: ["Alto Rendimiento", "Retorno Energía", "Estabilidad", "Ligereza"],
        rating: 4.5,
        reviews: 87,
        specifications: {
            weight: "0.6 kg",
            material: "Carbono Avanzado",
            energyReturn: "90%",
            warranty: "2 años"
        }
    },

    // Finger Prosthetics
    {
        id: 11,
        name: "Prótesis de Dedos Articulada",
        category: "dedos",
        type: "mecanica",
        price: 5000,
        originalPrice: 6500,
        image: "https://images.pexels.com/photos/8376288/pexels-photo-8376288.jpeg?auto=compress&cs=tinysrgb&w=400",
        description: "Prótesis de dedos con articulaciones móviles y control individual.",
        features: ["Articulaciones Móviles", "Control Individual", "Silicona Médica", "Personalizable"],
        rating: 4.3,
        reviews: 76,
        specifications: {
            weight: "0.05 kg",
            material: "Silicona + Titanio",
            flexibility: "Natural",
            warranty: "2 años"
        }
    },
    {
        id: 12,
        name: "Dedos Biónicos con Sensores",
        category: "dedos",
        type: "mioeléctrica",
        price: 12000,
        originalPrice: 15000,
        image: "https://images.pexels.com/photos/8376289/pexels-photo-8376289.jpeg?auto=compress&cs=tinysrgb&w=400",
        description: "Dedos protésicos con sensores táctiles y control mioeléctrico preciso.",
        features: ["Sensores Táctiles", "Control Preciso", "Feedback Haptico", "Resistente Agua"],
        rating: 4.7,
        reviews: 94,
        specifications: {
            weight: "0.08 kg",
            batteryLife: "8 horas",
            sensitivity: "Alta",
            warranty: "3 años"
        }
    },

    // Facial Prosthetics
    {
        id: 13,
        name: "Prótesis Facial Personalizada",
        category: "facial",
        type: "cosmética",
        price: 18000,
        originalPrice: 22000,
        image: "https://images.pexels.com/photos/8376290/pexels-photo-8376290.jpeg?auto=compress&cs=tinysrgb&w=400",
        description: "Prótesis facial ultra-realista creada con escaneo 3D y materiales premium.",
        features: ["Ultra-realista", "Escaneo 3D", "Materiales Premium", "Ajuste Perfecto"],
        rating: 4.8,
        reviews: 65,
        specifications: {
            weight: "0.2 kg",
            material: "Silicona Médica",
            customization: "100%",
            warranty: "3 años"
        }
    },
    {
        id: 14,
        name: "Prótesis Ocular Avanzada",
        category: "facial",
        type: "cosmética",
        price: 8500,
        originalPrice: 11000,
        image: "https://images.pexels.com/photos/8376291/pexels-photo-8376291.jpeg?auto=compress&cs=tinysrgb&w=400",
        description: "Prótesis ocular con movimiento sincronizado y apariencia natural.",
        features: ["Movimiento Sincronizado", "Apariencia Natural", "Biocompatible", "Fácil Limpieza"],
        rating: 4.6,
        reviews: 89,
        specifications: {
            weight: "0.02 kg",
            material: "Acrílico Médico",
            movement: "Sincronizado",
            warranty: "2 años"
        }
    },

    // Advanced Prosthetics
    {
        id: 15,
        name: "Sistema Protésico Completo Brazo",
        category: "brazo",
        type: "mioeléctrica",
        price: 65000,
        originalPrice: 75000,
        image: "https://images.pexels.com/photos/8376292/pexels-photo-8376292.jpeg?auto=compress&cs=tinysrgb&w=400",
        description: "Sistema completo de brazo con hombro, codo y mano integrados con IA.",
        features: ["Sistema Completo", "IA Integrada", "Control Mental", "Feedback Neural"],
        rating: 5.0,
        reviews: 45,
        specifications: {
            weight: "2.5 kg",
            batteryLife: "18 horas",
            aiFeatures: "Avanzadas",
            warranty: "5 años"
        }
    },
    {
        id: 16,
        name: "Exoesqueleto de Piernas Motorizado",
        category: "pierna",
        type: "mioeléctrica",
        price: 85000,
        originalPrice: 95000,
        image: "https://images.pexels.com/photos/8376293/pexels-photo-8376293.jpeg?auto=compress&cs=tinysrgb&w=400",
        description: "Exoesqueleto motorizado para rehabilitación y movilidad asistida.",
        features: ["Motorizado", "Rehabilitación", "Sensores Múltiples", "Control Inteligente"],
        rating: 4.9,
        reviews: 32,
        specifications: {
            weight: "15 kg",
            batteryLife: "6 horas",
            maxSpeed: "5 km/h",
            warranty: "4 años"
        }
    },
    {
        id: 17,
        name: "Prótesis de Mano Impresa 3D",
        category: "mano",
        type: "mecanica",
        price: 3500,
        originalPrice: 5000,
        image: "https://images.pexels.com/photos/8376294/pexels-photo-8376294.jpeg?auto=compress&cs=tinysrgb&w=400",
        description: "Prótesis de mano fabricada con impresión 3D, personalizable y económica.",
        features: ["Impresión 3D", "Personalizable", "Económica", "Rápida Fabricación"],
        rating: 4.2,
        reviews: 156,
        specifications: {
            weight: "0.3 kg",
            material: "PLA Médico",
            printTime: "24 horas",
            warranty: "1 año"
        }
    },
    {
        id: 18,
        name: "Prótesis Infantil Adaptable",
        category: "brazo",
        type: "mecanica",
        price: 8500,
        originalPrice: 11000,
        image: "https://images.pexels.com/photos/8376295/pexels-photo-8376295.jpeg?auto=compress&cs=tinysrgb&w=400",
        description: "Prótesis diseñada para niños con crecimiento adaptable y colores personalizables.",
        features: ["Crecimiento Adaptable", "Colores Personalizables", "Segura", "Ligera"],
        rating: 4.8,
        reviews: 78,
        specifications: {
            weight: "0.4 kg",
            ageRange: "5-15 años",
            adjustable: "Sí",
            warranty: "2 años"
        }
    },
    {
        id: 19,
        name: "Prótesis de Pierna Inteligente",
        category: "pierna",
        type: "mioeléctrica",
        price: 52000,
        originalPrice: 58000,
        image: "https://images.pexels.com/photos/8376296/pexels-photo-8376296.jpeg?auto=compress&cs=tinysrgb&w=400",
        description: "Prótesis con sensores de equilibrio, GPS integrado y análisis de marcha.",
        features: ["Sensores Equilibrio", "GPS Integrado", "Análisis Marcha", "Conectividad"],
        rating: 4.7,
        reviews: 91,
        specifications: {
            weight: "2.3 kg",
            batteryLife: "30 horas",
            connectivity: "Bluetooth/WiFi",
            warranty: "4 años"
        }
    },
    {
        id: 20,
        name: "Kit de Herramientas Protésicas",
        category: "accesorios",
        type: "mecanica",
        price: 2500,
        originalPrice: 3200,
        image: "https://images.pexels.com/photos/8376297/pexels-photo-8376297.jpeg?auto=compress&cs=tinysrgb&w=400",
        description: "Kit completo de herramientas especializadas para mantenimiento de prótesis.",
        features: ["Kit Completo", "Herramientas Especializadas", "Manual Incluido", "Estuche"],
        rating: 4.4,
        reviews: 123,
        specifications: {
            weight: "1.2 kg",
            tools: "15 herramientas",
            case: "Resistente",
            warranty: "1 año"
        }
    }
]